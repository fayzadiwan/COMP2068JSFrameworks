LAB04 Submission bundle

What I created for you:
- backend/ : fully working Express backend (in-memory data)
- frontend-stub/ : Angular CLI project files to copy into a generated Angular project

How to run (recommended):
1. Backend:
   cd backend
   npm install
   npm start
   (server runs at http://localhost:3000)

2. Frontend:
   - If you haven't already, create the Angular app:
     ng new comp2068-lab04-frontend
     cd comp2068-lab04-frontend
   - Copy contents of frontend-stub/src/app/ into src/app/
   - Copy proxy.conf.json from frontend-stub/ to project root
   - Run:
     ng serve --proxy-config proxy.conf.json
   - Open http://localhost:4200

Uploading to your class repo:
- Create a new folder LAB04 in your class repository and push the `backend/` folder and the `frontend-stub/` folder (or the full generated Angular project).
- Commit message suggestion: "LAB04 - Angular SPA + Express backend (COMP2068)"
