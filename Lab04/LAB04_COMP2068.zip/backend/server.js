// Simple Express backend for COMP2068 LAB04
// Run: npm install && node server.js
const express = require('express');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

let items = [
  { id: 1, title: 'Buy groceries', completed: false },
  { id: 2, title: 'Finish COMP2068 lab', completed: true }
];

// GET all
app.get('/api/items', (req, res) => {
  res.json(items);
});

// GET by id
app.get('/api/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const it = items.find(i => i.id === id);
  if (!it) return res.status(404).json({ error: 'Not found' });
  res.json(it);
});

// POST create
app.post('/api/items', (req, res) => {
  const { title } = req.body;
  if (!title) return res.status(400).json({ error: 'title required' });
  const id = items.length ? Math.max(...items.map(i => i.id)) + 1 : 1;
  const newItem = { id, title, completed: false };
  items.push(newItem);
  res.status(201).json(newItem);
});

// PUT update
app.put('/api/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const it = items.find(i => i.id === id);
  if (!it) return res.status(404).json({ error: 'Not found' });
  const { title, completed } = req.body;
  if (title !== undefined) it.title = title;
  if (completed !== undefined) it.completed = completed;
  res.json(it);
});

// DELETE
app.delete('/api/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const idx = items.findIndex(i => i.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  const removed = items.splice(idx, 1);
  res.json({ success: true, removed: removed[0] });
});

app.listen(port, () => {
  console.log(`Backend running on http://localhost:${port}`);
});
