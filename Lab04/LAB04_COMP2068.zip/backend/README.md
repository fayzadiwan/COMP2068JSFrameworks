# Backend (Express)

Run:

```
cd backend
npm install
npm start
```

API endpoints:
- GET /api/items
- GET /api/items/:id
- POST /api/items { title }
- PUT /api/items/:id { title, completed }
- DELETE /api/items/:id
