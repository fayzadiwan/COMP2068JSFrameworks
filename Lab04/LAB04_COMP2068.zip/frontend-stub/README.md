# Frontend (Angular) - instructions and files to copy into an Angular CLI project

Steps to create the Angular project and use provided files:

1. Install Angular CLI (if not installed):
   ```
   npm install -g @angular/cli
   ```
2. Create a new Angular project (use routing: yes, stylesheet: css)
   ```
   ng new comp2068-lab04-frontend
   cd comp2068-lab04-frontend
   ```
3. Copy the files from this `frontend-stub/src/app/` into `src/app/` of the Angular project (replace existing files if prompted).
4. Place `proxy.conf.json` at the project root (this file in the stub).
5. Update `angular.json` serve options to include the proxy or run:
   ```
   ng serve --proxy-config proxy.conf.json
   ```
6. Run the backend first (see backend README), then run the frontend.

The provided files implement a simple Task list with CRUD using the Express backend.
