import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div class="container">
  <h1>COMP2068 LAB04 - Tasks SPA</h1>
  <app-task-list></app-task-list>
</div>`,
  styles: [`.container { max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif; }`]
})
export class AppComponent { }
