import { Component, OnInit } from '@angular/core';
import { TaskService, Task } from '../task.service';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
  tasks: Task[] = [];
  newTitle = '';
  editing: { [key:number]: boolean } = {};

  constructor(private svc: TaskService) { }

  ngOnInit(): void { this.load(); }

  load() {
    this.svc.list().subscribe(t => this.tasks = t);
  }

  add() {
    if (!this.newTitle.trim()) return;
    this.svc.create(this.newTitle.trim()).subscribe(_ => {
      this.newTitle = '';
      this.load();
    });
  }

  toggle(task: Task) {
    task.completed = !task.completed;
    this.svc.update(task).subscribe();
  }

  save(task: Task) {
    this.svc.update(task).subscribe(() => this.editing[task.id] = false);
  }

  remove(id: number) {
    this.svc.delete(id).subscribe(() => this.load());
  }

  edit(task: Task) {
    this.editing[task.id] = true;
  }
}
